const express = require("express");
const bodyParser = require("body-parser");
const handbar = require("express-handlebars");
const cookieParse = require("cookie-parser");
const bcrypt = require("bcrypt");
const path = require("path");
const app = express();
const users = require("./users");

var curr_user = "";
app.use(bodyParser.json());
app.use(cookieParse());
app.use(bodyParser.urlencoded({extended:true}));

app.get("/", (req, res) => {
  //check if have cookie, if so then go to private, else login
  if(req.cookies.AuthCookie){
    res.redirect('/private');
  }
  res.sendFile(path.resolve("login.html"));
})

app.post("/login", (req, res) => {
  const username = req.body.username;
  curr_user = username;
  const hashed_password = users.get_hash(username);
  //check if password is right
  bcrypt.compare(req.body.password, hashed_password, function(err, result) {
    if(!result){
        //redirect to error page
        res.sendFile(path.resolve("loginError.html"))
    }
    else {
      res.cookie("AuthCookie", username);
      res.redirect('/private');
    }
  });
});

app.get("/login", (req, res) => {
  res.sendFile(path.resolve("login.html"));
});
app.get("/logout", (req, res) => {
  res.clearCookie("AuthCookie");
  console.log("got into logout");
  res.sendFile(path.resolve("logout.html"));
});


//uses the middleware thingy
app.use("/private", (req, res, next) => {
  if (!(req.cookies.AuthCookie)) {
    res.status(403).send("Can't do that when not logged in");
    res.redirect("/");
  }
  next();
});

app.get("/private", (req, res) => {
  if(curr_user == "lemon"){
      res.sendFile(path.resolve("public/content/lemon.html"));
  }
  else if (curr_user == "masterdetective123") {
    res.sendFile(path.resolve("public/content/sherlock.html"));
  }
  else if(curr_user == "theboywholived"){
    res.sendFile(path.resolve("public/content/harrypotter.html"));
  }
  else {
    res.status(404).send("Could not find user page");
  }
});

app.listen(3000, function() {
    console.log("Your server is now listening on port 3000! Navigate to http://localhost:3000 to access it");

    if (process && process.send) process.send({done: true}); // ADD THIS LINE
});
