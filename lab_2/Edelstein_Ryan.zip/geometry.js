
'use strict'
function volumeOfrectangularPrism(length, width, height){

  if(isNaN(length) || isNaN(width) || isNaN(height)){
    return `THE INPUT MUST BE A NUMBER`;
  }
  if(length == null || width == null || height == null){
    return `INVALID INPUT`;
  }
  if(length <= 0 || width <= 0 ||  height <=0){
    console.log("Volume cannot be less than or equal to 0")
  }
  let volume  = length * width * height;
  return volume;
}

function surfaceAreaOfRectangularPrism(length,width, height) {
  if(isNaN(length) || isNaN(width) || isNaN(height)){
    return `THE INPUT MUST BE A NUMBER`;
  }
  if(length == null || width == null || height == null){
    return `INVALID INPUT`;
  }
  if(length <= 0 || width <= 0 ||  height <=0){
    console.log("A dimension of a 3D object cannot be less than or equal to 0")
  }
  let surfaceArea = 2*((width*length)+(height*length)+ (height*width));
  return surfaceArea;
}

function volumeOfSphere(radius){
    if(isNaN(radius)){
      return `THE INPUT MUST BE A NUMBER`;
    }
    if(radius == null){
      console.logs("Radius cannot be null");
    }
    if(radius <= 0){
      console.log("Radius cannot be less than or equal to 0");
    }
    let sphereVolume = Math.round(1.33*(Math.PI*Math.pow(radius, 3)));
    return sphereVolume;
}

function surfaceAreaofSphere(radius){
  if(isNaN(radius)){
    return `THE INPUT MUST BE A NUMBER`;
  }
  if(radius == null){
    console.logs("Radius cannot be null");
  }
  if(radius <= 0){
    console.log("Radius cannot be less than or equal to 0");
  }
  let sphere = Math.round(4*(Math.PI*Math.pow(radius, 2)));
  return sphere;
}



module.exports = {
    firstName: "Ryan",
    lastName: "Edelstein",
    studentId: "10410555",
    volumeOfrectangularPrism,
    volumeOfSphere,
    surfaceAreaofSphere,
    surfaceAreaOfRectangularPrism
};
