'use strict'

const test = require("./geometry.js");
const test2 = require("./utilities.js")
let volumeOfrectangularPrism = test.volumeOfrectangularPrism(4,3,4);
console.log(`the volumeOfrectangularPrism is ${volumeOfrectangularPrism}`);
if(volumeOfrectangularPrism != 48){ //base test to see if it works (it does)
  throw `THE VOLUME OF A RECT PRISM IS INCORRECT ${volumeOfrectangularPrism}`;
}else{
  console.log("Volume of Rectangular Prism works when given 3 numbers!");
}

//console.log(test.volumeOfrectangularPrism(x,3,2)); //test if it works letters (it shouldnt)
console.log(test.volumeOfrectangularPrism(-1,4,3)); //should throw error if less than 0
console.log(test.volumeOfrectangularPrism(1,5)); //test if it works with null input. or if the input is valid.
console.log(test.volumeOfrectangularPrism(0,1,3)); //test if 0 works. Shoudlnt, volume cannot be 0



console.log("------------------------------------------------------------------")
let surfaceAreaOfRectangularPrism = test.surfaceAreaOfRectangularPrism(4,3,4);
console.log(`the surfaceAreaOfRectangularPrism is ${surfaceAreaOfRectangularPrism}`);
//test if it works in general ( it does)
if(surfaceAreaOfRectangularPrism != 80){
  throw " THE SURFACE AREA OF A RECT PRISM IS INCORRECT";
}else if(surfaceAreaOfRectangularPrism <= 0){
  console.log("Surface area of Rectangular prism cannot be less than or equal to 0");
}


//test with negative input
console.log(test.surfaceAreaOfRectangularPrism(-2,4,3));
//test with null input
console.log(test.surfaceAreaOfRectangularPrism());
//test with non numerical input
console.log(test.surfaceAreaOfRectangularPrism("x",2,3));
//test with 0 as input surface area cannot be 0.
console.log(test.surfaceAreaOfRectangularPrism(0,2,1));
console.log("------------------------------------------------------------------")

let volumeOfSphere = test.volumeOfSphere(2);
console.log(`the volumeOfSphere is ${volumeOfSphere}`);
//test if it actually works
if (volumeOfSphere != 33) {
  throw " THE VOLUME OF A SPHERE IS INCORRECT";
} else {
  console.log("Volume of a sphere works when given a radius!");
}


console.log(test.volumeOfSphere(0));
console.log(test.volumeOfSphere("x"));
console.log(test.volumeOfSphere(-1));

//test with negative input


console.log("------------------------------------------------------------------")
let surfaceAreaofSphere = test.surfaceAreaofSphere(2);
console.log(`the surfaceAreaofSphere is ${surfaceAreaofSphere}`);

if (surfaceAreaofSphere != 50) {
  throw "THE SURFACE AREA OF A SPHERE IS INCORRECT";
} else {
  console.log("Surface area of a sphere works when given a radius!");
}

try{
  let radiusNeg = test.surfaceAreaofSphere(-1);
} catch (e) {
  console.log("The radius cannot be negative");
}

console.log(test.surfaceAreaofSphere(0));
console.log(test.surfaceAreaofSphere("x"));
console.log(test.surfaceAreaofSphere(-1));

//////////////////////test2//////////////////////////////////////////////////////
console.log("------------------------------------------------------------------")

                  //should be 5
const testArr = ["a", "a", "b", "a", "b", "c", "d", "f"]; //tested on unsorted array
let uniqueElements = test2.uniqueElements(testArr);

if(uniqueElements != 5){
  throw `THE NUMBER OF UNIQUE ELEMENTS IS INCORRECT ${uniqueElements}`;
}else{
  console.log(`The number of uniqueElements is correct ${uniqueElements}`)
}

console.log(test2.uniqueElements([])); //test for empty arrayLength Should be 0;
console.log(test2.uniqueElements(["a", "2", "b", "3"])); //tested for a list of numbers and letters
console.log(test2.uniqueElements(["a", "b", "c"])); //tested on an already sorted array
console.log(test2.uniqueElements(["b"])); //returns 1 for array of length 1


console.log("------------------------------------------------------------------");
let testStr = "Hello, the pie is in the oven";
let countOfEachCharacterInString = test2.countOfEachCharacterInString(testStr);
if(countOfEachCharacterInString ===
{ ' ': 6,
  ',': 1,
  H: 1,
  e: 5,
  h: 2,
  i: 3,
  l: 2,
  n: 2,
  o: 2,
  p: 1,
  s: 1,
  t: 2,
  v: 1
})
 {
   throw `THE COUNT OF EACH CHAR IN STRING WAS INCORRECT countOfEachCharacterInString`
   console.log("countOfEachCharacterInString");
 } else{
   console.log("The count of each character in the string was correct\ncountOfEachCharacterInString");
 }

console.log(test2.countOfEachCharacterInString("Hello, the pie is in the oven")); //first test
console.log(test2.countOfEachCharacterInString(""));//test on empty string

console.log(test2.countOfEachCharacterInString("Test with numbers 4 5 1"));
console.log(test2.countOfEachCharacterInString("Test with multiple spaces             "));
console.log(test2.countOfEachCharacterInString("t"))//test with 1 character
console.log(test2.countOfEachCharacterInString()); //returns that the string is undefined

console.log("------------------------------------------------------------------");


const first = {a: 2, b: 3};
const second = {a: 2, b: 4};
const third = {a: 2, b: 3};
  let deepEquality = test2.deepEquality(first, second);
console.log(test2.deepEquality(first,second));
// console.log(deepEquality(first, second)); // false
 console.log(test2.deepEquality(first, third)); // true
const empty = {};
const testeroni = {b:3};
console.log(test2.deepEquality(first, empty)); //false
console.log(test2.deepEquality(first, testeroni)); //false
console.log(test2.deepEquality(second, empty));
console.log(test2.deepEquality(second, testeroni));
